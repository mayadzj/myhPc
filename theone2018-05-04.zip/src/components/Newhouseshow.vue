<template>
  <div id="newhouse">
    <div class="news_ban"><img  src="../assets/images/newhouse.jpg" /></div>
    <div class="sub_content">
      <div class="sub_wid">
        <h2 class="house_nh new_title"><a href="###">全部房源</a></h2>
        <div class="select_menu">
          <a class="sela" href="#" :style="c==true?'color:#ff6600':''" @click="number(a)">默认排序</a>
          <a class="sanjiao"  href="#" :style="c==false?'color:#ff6600':''"   @click="btnprice(a)">价格<span class="bian" v-if="price"></span><span v-else></span></a>
          <p class="sel03" >共有{{mynum}}个楼盘</p>
        </div>
        <div class="app_con newsall">
          <div class="app_lef new_lef">
            <div class="newhouseall">
              <!---an---->

              <div class="newlist_an" v-for="hous in housedata">
                <router-link tag="a" :to="'/Housesay/'+hous.id">
                <div class="newhouseall_left"><a href="#"><img :src="hous.mainImg" /> </a></div>
                <div class="newhouseall_right">
                  <ul class="house_fonts">
                    <li class="hft_01"><a href="#">{{hous.subTitle}}</a><p>均价<b>{{hous.averagePrice}}</b>元/㎡</p></li>
                    <li class="hft_02"><strong>{{hous.address}}</strong><p><img src="../assets/images/call.png" />400-1133-233</p></li>
                    <li class="hft_03"><p>户型：{{hous.layout}}</p></li>
                    <li class="hft_04"><p>建筑面积：{{hous.measure}}㎡ </p></li>
                    <li class="hft_05"><p class="hft_cor2">{{hous.houseType}}</p> </li>
                  </ul>
                </div>
                </router-link>
              </div>
              <!---an---->

              <div class="pageall">
                <el-pagination
                  background
                  layout="prev, pager, next"
                  @current-change="handleCurrentChange"
                  :page-size="pageSize"
                  :total="mynum">
                </el-pagination>
              </div>
            </div>
          </div>
          <div class="app_rig amarg"><Indexslideview></Indexslideview></div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import 'element-ui/lib/theme-chalk/index.css'
import {Pagination} from 'element-ui'
import  Indexslideview from '../components/Indexslide'
export default {
  name: 'newhouse',
  data () {
    return {
      stateshow: '',
      housedata: {},
      price: true,
      mynum: '',
      getTitle: '',
      a: '1',
      c: true,
      menua: {
        'color': '#ff6600'
      },
      twodata: [
        {
          id: 1,
          name: '御道庄园'
        },
        {
          id: 2,
          name: '财富九龙城'
        },
        {
          id: 3,
          name: '兴隆融创城'
        },
        {
          id: 4,
          name: '荣盛阿尔卡迪亚'
        },
        {
          id: 5,
          name: '兴隆碧桂园'
        }
      ],
      currentpage: '1',
      pageSize: '10'
    }
  },
  components: {
    Indexslideview,
    'el-pagination': Pagination
  },
  mounted () {
    this.loadrun()
    this.houseall()
  },
  methods: {
    loadrun () {
      var nhs = this.$route.params.id
      if(!nhs){
        this.getTitle = ''
        this.houseall()
        return
      }
      nhs = nhs - 1
      this.getTitle = this.twodata[nhs].name
      this.houseall()
    },
    btnprice () {
      this.price = !this.price
      this.c = false
      if (this.a == 0) {
        this.a = 1
      } else {
        this.a = 0
      }
      this.houseall()
    },
    number () {
      this.c = true
      this.a = 1
      this.houseall()
    },
    handleCurrentChange(val) {
      this.currentpage = val
      this.houseall()
    },
    houseall () {
      var ty = {
        type: 1,
        priceSort: this.a,
        pageNum: this.currentpage,
        pageSize: this.pageSize
      }
      this.$http.post('/api/myh_web/viewHouseInfo', ty).then((response) => {
        var data = response.data
        data = data.resultBean
        data = data.object
        var num = data.total
        this.mynum = num
        data = data.list
        if (this.getTitle == '') {
          this.housedata = data
          return
        }
        var arr = []
        for (var i = 0; i < data.length; i++) {
          var newdatas = data[i].subTitle
          if (newdatas == this.getTitle){
            arr.push(data[i])
          }
        }
        this.housedata = arr
      })
    }
  },
  watch: {
    $route (r) {

      var nhs = r.params.id

      if(!nhs){
        this.getTitle = ''
        this.houseall()
        return
      }
      nhs = nhs - 1
      this.getTitle = this.twodata[nhs].name
      this.houseall()
    }
  }
}
</script>

<style scoped>
.select_menu{
  display: block;
  padding: 0px 20px 15px 20px;
  border-bottom: 10px solid #f1f1f1;
  margin-bottom: 30px;
}
.sela{
  font-size: 16px;
  text-decoration: none;
  margin-right: 20px;
}
.sel03{
  color: #666666;
  font-size: 16px;
  float: right;
}
.sanjiao { color: #333333; font-size:16px; position: relative; text-decoration: none;padding-right: 18px;}
.sanjiao span { border: 6px solid #666666; border-top-color: transparent; border-left-color: transparent; border-right-color: transparent; display: inline-block; position: absolute; top: 0.28125rem; right: 0.04688rem; }
.sanjiao .bian { border-top-color: #666666; border-bottom-color: transparent; border-left-color: transparent; border-right-color: transparent; display: inline-block; position: absolute; top: 0.3rem; right: 0.04688rem; }
.pageall{
  display: block;
  overflow: hidden;
  width: 100%;
  margin: 20px auto;
  text-align: center;
}
</style>
