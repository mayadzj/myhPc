<template>
  <div id="login">
    <div class="lg_reg_content">
      <div class="lgreg_wid">
      <div class="lg_lef">
        <div class="lg_tit"><a href="#"  @click="showWhich(1)"  :id="showDiv==1?'lg_tita':''">登录</a><b>|</b><a  @click="showWhich(2)" :id="showDiv==2?'lg_tita':''" href="#">注册</a></div>
        <!-----切换登录-------->
        <div v-show="showDiv==1" class="lg_list_slide">
          <div class="login">
            <ul class="fromlist">
              <li><input type="text" placeholder="请输入手机号"   v-model="myphone" class="rgphone" /></li>
              <li><input type="password" placeholder="请输入密码" v-model="lpwd"  class="rgpwd" /></li>
              <li><a href="#" class="rgmm">忘记密码</a></li>
              <li><input type="button" value="立即登录" @click="lgbtn"  class="btn_reg" /></li>
              <li><p class="tsmessage">{{tsmessage}}</p></li>
            </ul>
          </div>
        </div>
        <!-----切换注册-------->
        <div  v-show="showDiv==2"  class="lg_list_slide">
          <div class="regster">
            <ul class="fromlist">
              <li><input type="text" placeholder="请输入手机号" class="rgphone" v-model="addphone" /></li>
              <li><input type="text" placeholder="请输入短信验证码" class="rgma" v-model="addyzm" />
                <a class="from_mm"  @click="regsend" href="#">
                  <span v-if="sendMsgDisabled">{{time+'s重新获取'}}</span>
                  <span v-if="!sendMsgDisabled">发送验证码</span>
                </a>
              </li>
              <li><input type="text" placeholder="请输入昵称" v-model="addname" class="rgname"/></li>
              <li><input type="password" placeholder="请输入密码(6-12位字母数字)" v-model="addpwd" class="rgpwd" /></li>
              <li><input type="password" placeholder="请确认密码" class="rgpwd" v-model="addokpwd" /></li>
              <li><input type="submit" value="注册"  class="btn_reg" @click="regbtn" /></li>
              <li><p class="tsmessage">{{regmessage}}</p></li>
            </ul>
          </div>
        </div>
      </div>
        <div class="lg_rig">
          <p>使用微信直接登录</p>
          <p><img src="../assets/images/wxico.jpg" /></p>
          <a href="#"><img src="../assets/images/ewm.jpg" /></a>
          <p>{扫描满易何公众号}</p>
        </div>
        <!-----------成功提示弹出层-------------->
      <div class="prop_reg" v-show="prop">
        <div class="screens"></div>
        <div class="regsuccess">
           <!--<a class="regclose" href="#"><img src="../assets/images/close.png" width="30" /></a>-->
           <h2 class="regh2" ><img src="/static/images/success.png" width="60"/> </h2>
           <h2 class="regh2" >帐号注册成功!</h2>
           <a class="regnum" href="#">{{stime+'s后跳转到首页'}}</a>
        </div>
      </div>
    </div>
    </div>

  </div>
</template>

<script>
import md5 from 'js-md5'
import {setCookie,getCookie} from '../util/cookie'
// import  qs from 'qs'
export default {
  name: 'login',
  data () {
    return {
      tsmessage: '',
      regmessage: '',
      myphone: '',
      lpwd: '',
      showDiv: '',
      showDib: true,
      addphone: '',
      addyzm: '',
      addname: '',
      addpwd: '',
      addokpwd: '',
      prop: false,
      time: 60,
      sendMsgDisabled: false,
      stime: 3,
      interval: '',
      timeval: null,
      addmingzi: '',
      addshenfenzheng: ''
    }
  },
  mounted () {
    this.loadFun()
  },
  methods: {
    showWhich(id){
      this.showDiv = id
    },
    // 登录接口数据
    lgbtn () {
      // 验证手机号
      var reg = 11 && /^((13|14|15|17|18)[0-9]{1}\d{8})$/
      if ( !this.myphone) {
        this.tsmessage = '请输入手机号码!'
        this.clearTsmessage()
        return
      }
      if ( !reg.test(this.myphone)) {
        this.tsmessage = '手机号码格式不正确!'
        this.clearTsmessage()
        return
      }
      if (!this.lpwd)
      {
        this.tsmessage = '请输入密码!'
        this.clearTsmessage()
        return
      }
      if (6 > this.lpwd.length || 12 < this.lpwd.length) {
        this.tsmessage = '密码输入不正确!'
        this.clearTsmessage()
        return
      }

      var infos = {
        'mobile': this.myphone,
        'password': md5(this.lpwd)
      }
      this.$http.post('/api/myh_web/login', infos).then((response) => {
        console.log(response)
        var data = response.data
        data = data.resultBean
        var mydate = data.object
        var res = data.code
        if (res == '1') {
          // alert(data.message)
          this.tsmessage = data.message
        } else if (res == '0') {
          setCookie('sessionId',data.sessionId,5)
          setCookie('userId',mydate.id,5)
          setCookie('myhPhone',this.myphone,5)
          this.$store.dispatch('loginSave',{'sessionId':data.sessionId,myhPhone:this.myphone,userId:mydate.id})
          this.$router.push('/')
        }
      })
    },
    // 注册验证码接口
    regsend () {
      var reg = 11 && /^((13|14|15|17|18)[0-9]{1}\d{8})$/;
      if (this.addphone == '') {
        this.regmessage = '手机号不能为空！'
        this.clearRegMessage()
        return
      }
      if (!reg.test(this.addphone)){
        this.regmessage = '手机号码格式不正确!'
        clearRegMessage()
        return
      }
      if (this.addyzm == ''){
        this.regmessage = '验证码不能为空!'
        clearRegMessage()
        return
      }
      if (this.sendMsgDisabled) {
        return
      }
      var addfrom = {
        mobile: this.addphone,
        type: 'regist'
      }
      this.$http.post('/api/myh_web/getValiCode', addfrom).then((response) => {
        var data = response.data
        data = data.resultBean
        var yzm = data.code
        if (yzm == '1') {
          this.regmessage = data.message
        }else if (yzm == '0') {
          let me = this
          me.sendMsgDisabled = true
          this.timeval = window.setInterval(function () {
            if ((me.time--) <= 0) {
              me.time = 60
              me.sendMsgDisabled = false
              window.clearInterval(timeval)
            }
          }, 1000)
        }
      })
    },
    // 注册列表接口
    regbtn () {
      var reg = 11 && /^((13|14|15|17|18)[0-9]{1}\d{8})$/;
      if (this.addphone == '') {
        this.regmessage = '手机号不能为空！'
        this.clearRegMessage()
        return
      }
      if (!reg.test(this.addphone)){
        this.regmessage = '手机号码格式不正确!'
        clearRegMessage()
        return
      }
      if (this.addyzm == ''){
        this.regmessage = '验证码不能为空!'
        clearRegMessage()
        return
      }
      if (this.addname == ''){
        this.regmessage = '昵称不能为空!'
        clearRegMessage()
        return
      }
      if (this.addpwd.length < 6 || this.addpwd.length > 12){
        this.regmessage = '密码输入不正确!'
        clearRegMessage()
        return
      }
      if (this.addpwd != this.addokpwd) {
        this.regmessage = '两次密码输入不一致!'
        clearRegMessage()
        return
      }
      var addlist = {
        mobile: this.addphone,
        valiCode: this.addyzm,
        name: this.addname,
        password: md5(this.addpwd),
        password2: md5(this.addokpwd)
      }
      this.$http.post('/api/myh_web/register', addlist).then((response) => {
        var regdata = response.data
        regdata = regdata.resultBean
        var  rcs = regdata.code
        if (rcs == '1') {
          console.log(regdata.message)
          this.regmessage = regdata.message
        } else if (rcs == '0') {
          let rths = this
          rths.prop = true
          rths.interval = window.setInterval(function () {
            if ((rths.stime--) <= 1) {
              window.clearInterval(rths.interval)
              rths.prop = false
              rths.showDiv = true
            }
          },1000)
        }
      })
    },
    loadFun () {
      var cate = this.$route.params.cate
      cate = parseInt(cate)
      if (cate === 2) {
        this.showDiv = false
      }
      if (cate === 1) {
        this.showDiv = true
      }
    },
    clearRegMessage () {
      var that = this
      setTimeout(function () {
        that.regmessage=''
      }, 3000)
    },
    clearTsmessage () {
      var that = this
      setTimeout(function () {
        that.tsmessage = ''
      }, 3000)
    }

  }
}
</script>

<style scoped>

</style>
