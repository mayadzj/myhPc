<template>
    <div id="memberfeedback">
      <div class="fk">
        <div class="fk-tit">
          <p>用户反馈</p>
        </div>
        <div class="fk-wap">
          <div class="jq clear">
            <img src="images/jq.png" alt="">
            <p>满易何帮帮小管家</p>
          </div>
          <div class="jq-time">
            <p>2016-05-02 20:43:23</p>
            <p>亲~您好！很高兴为您服务，有什么可以帮您的呢？我们收到后会以邮件形式发给您哦！</p>
          </div>
          <div class="jq-user clear">
            <div class="user-pic">
              <img src="images/jq.png" alt="">
            </div>
            <div class="user-char">
              您好，我想问御道庄园的房价为什么会变
            </div>
          </div>
          <form class="jq-feed" action="">
            <textarea name="" placeholder="点击输入您想要咨询的问题...（字数仅限300字以内）" ></textarea>
            <input type="submit" value="发送">
            <img src="images/tp.png" alt="">
          </form>
        </div>
      </div>
    </div>
</template>

<script>
export default {
  name: 'memberfeedback'
}
</script>

<style scoped>

</style>
