export default {
  lgben (state) {
    return state.lgben
  },
  sessionId (state) {
    return state.sessionId
  },
  myhPhone (state) {
    return state.myhPhone
  },
  isLogin (state) {
    return state.isLogin
  },
  userId(state) {
    return state.userId
  },
  searchHistory(state) {
    return state.searchHistory
  },
  carscreens(state){
    return state.carscreen
  }
}
