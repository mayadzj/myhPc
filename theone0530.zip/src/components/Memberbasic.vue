<template>
    <div id="memberbasic">
      <div class="gr">
      <div class="gr-tit">
        <p>个人信息</p>
      </div>
      <div class="gr-wap">
        <div class="nav-head clear">
          <div class="nav-head-l">头像</div>
          <div class="nav-head-m">
            <img src="../assets/images/fang.jpg" alt="">
          </div>
          <div class="nav-head-b">
            <el-upload
              class="upload-demo"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :before-remove="beforeRemove"
              multiple
              :limit="3"
              :on-exceed="handleExceed"
              :file-list="fileList">
              <el-button size="small" type="primary">点击上传</el-button>
              <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
            </el-upload>
          </div>
        </div>
        <div class="nav-name">
          <p>昵称</p>
          <p>杨阳洋</p>
          <p>修改昵称</p>
        </div>
        <div class="nav-db1">
          <p>手机</p>
          <p>17610276866</p>
        </div>
        <div class="nav-db">
          <p>邮箱</p>
          <p>立即绑定</p>
        </div>
        <div class="nav-db">
          <p>密码</p>
          <p>修改密码</p>
        </div>
      </div>
      <div class="gai">
        <div class="gai-name">
          <form class="name-m" action="">
            <div class="m-zi clear">
              <p>设置昵称:</p>
              <input type="text" placeholder="请输入您的昵称">
            </div>
            <div class="m-but">
              <input type="submit" value="保存修改">
            </div>
          </form>
        </div>
        <div class="gai-sub">
          <div class="sub-m">
            <div class="m-one clear">
              <p>输入旧密码:</p>
              <input type="text" placeholder="请输入密码">
            </div>
            <div class="m-one clear">
              <p>设置新密码:</p>
              <input type="password" placeholder="请输入新密码">
            </div>
            <div class="m-one clear">
              <p>确认新密码:</p>
              <input type="password" placeholder="请确认新密码">
            </div>
            <div class="xian"></div>
            <div class="m-one clear">
              <p>手机号:</p>
              <input type="text" placeholder="为了账号安全，请填写本人手机号">
              <input type="submit" value="获取验证码">
            </div>
            <div class="m-one clear">
              <p>输入验证码:</p>
              <input type="text" placeholder="输入6位验证码">
              <span>60s</span>
            </div>
            <input class="m-sub" type="submit" value="保存修改">
          </div>
        </div>
      </div>
      </div>
    </div>
</template>

<script>
import {Upload,Dutton} from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
export default {
  name: 'memberbasic',
  data() {
    return {
      fileList: [{name: 'food.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}, {name: 'food2.jpeg', url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'}]
    };
  },
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    handleExceed(files, fileList) {
      this.$message.warning(`当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${ file.name }？`);
    }
  },
  components: {
    'el-upload': Upload,
    'el-button': Dutton
  },
  mounted(){
    this.uploads()
  },
  methods: {
    uploads(){
    }
  }
}
</script>

<style scoped>
  .gai{
    display: none;
  }
  .el-upload{

  }
</style>
