<template>
    <div id="register"></div>
</template>

<script>
export default {
  name: 'register'
}
</script>

<style scoped>

</style>
