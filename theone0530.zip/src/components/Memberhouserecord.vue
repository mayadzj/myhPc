<template>
    <div id="memberhouserecord">
      <div class="jl">
        <div class="jl-tit">
          <p>看房纪录</p>
        </div>
        <div class="jl-f clear">
          <div class="jl-fang">
            <div class="jl-pic">
              <img src="images/fang.jpg" alt="">
              <div class="jl-money">
                <p>320<span>万</span></p>
              </div>
            </div>
            <p class="jl-zi">
              10号线14号线地铁十里河大望路潘家园周庄嘉园a
            </p>
            <p class="jl-zi2">
              <span>2室1厅1卫</span>
              <span>100／㎡</span>
            </p>
          </div>
          <div class="jl-fang">
            <div class="jl-pic">
              <img src="images/fang.jpg" alt="">
              <div class="jl-money">
                <p>320<span>万</span></p>
              </div>
            </div>
            <p class="jl-zi">
              10号线14号线地铁十里河大望路潘家园周庄嘉园a
            </p>
            <p class="jl-zi2">
              <span>2室1厅1卫</span>
              <span>100／㎡</span>
            </p>
          </div>
          <div class="jl-fang">
            <div class="jl-pic">
              <img src="images/fang.jpg" alt="">
              <div class="jl-money">
                <p>320<span>万</span></p>
              </div>
            </div>
            <p class="jl-zi">
              10号线14号线地铁十里河大望路潘家园周庄嘉园a
            </p>
            <p class="jl-zi2">
              <span>2室1厅1卫</span>
              <span>100／㎡</span>
            </p>
          </div>
          <div class="jl-fang">
            <div class="jl-pic">
              <img src="images/fang.jpg" alt="">
              <div class="jl-money">
                <p>320<span>万</span></p>
              </div>
            </div>
            <p class="jl-zi">
              10号线14号线地铁十里河大望路潘家园周庄嘉园a
            </p>
            <p class="jl-zi2">
              <span>2室1厅1卫</span>
              <span>100／㎡</span>
            </p>
          </div>
          <div class="jl-fang">
            <div class="jl-pic">
              <img src="images/fang.jpg" alt="">
              <div class="jl-money">
                <p>320<span>万</span></p>
              </div>
            </div>
            <p class="jl-zi">
              10号线14号线地铁十里河大望路潘家园周庄嘉园a
            </p>
            <p class="jl-zi2">
              <span>2室1厅1卫</span>
              <span>100／㎡</span>
            </p>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
export default {
  name: 'memberhouserecord'
}
</script>

<style scoped>

</style>
