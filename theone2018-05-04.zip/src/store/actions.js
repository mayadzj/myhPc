export default {
  lgchou: ({commit}) => {
    // console.log('zhu')
    commit('lgchou')
  },
  loginSave:({commit},data)=>{
    commit('loginSave',data)
  }
}
