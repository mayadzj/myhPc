<template>
    <div id="memberlookhouse">
      <div class="kf">
        <div class="kf-tit">
          <p>预约看房</p>
        </div>
        <div class="kf-wap">
          <div class="nav-tit clear">
            <div class="nav-tit-l"></div>
            <div class="nav-tit-r">
              <div>预约时间</div>
              <div>集合时间</div>
              <div>项目地址</div>
              <div>集合地址</div>
              <div>看房电话</div>
              <div>操作</div>
            </div>
          </div>
          <div class="nav-con clear">
            <div class="nav-con-l"></div>
            <div class="nav-con-r">
              <div>
                <p>2016.05.02</p>
                <p>20:43:23</p>
              </div>
              <div>
                <p>2016.05.03</p>
                <p>08:43:23</p>
              </div>
              <div>
                <p>承德市</p>
                <p>御道庄园小区</p>
              </div>
              <div>
                <p>北京市顺义区</p>
                <p>南法信地铁站</p>
              </div>
              <div>
                <p>17610111011</p>
              </div>
              <div>
                <p>取消预约</p>
              </div>
            </div>
            <img class="zhang" src="images/zhang.png" alt="">
          </div>
          <div class="nav-con2 clear">
            <div class="nav-con2-l"></div>
            <div class="nav-con2-r">
              <div>
                <p>2016.05.02</p>
                <p>20:43:23</p>
              </div>
              <div>
                <p>2016.05.03</p>
                <p>08:43:23</p>
              </div>
              <div>
                <p>承德市</p>
                <p>御道庄园小区</p>
              </div>
              <div>
                <p>北京市顺义区</p>
                <p>南法信地铁站</p>
              </div>
              <div>
                <p>17610111011</p>
              </div>
              <div>
                <p>取消预约</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
export default {
  name: 'memberlookhouse'
}
</script>

<style scoped>

</style>
