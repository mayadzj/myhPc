<template>
    <div id="membermenu">
      <div class="my-l-top">
        <div class="my-pic">
          <img src="../assets/images/head.png" alt="">
        </div>
        <p>欢迎您,你好</p>
      </div>
      <div class="my-l-bottom">
        <ul class="clear">
          <li><router-link to="/Memberindex/Memberbasic"><img src="../assets/images/wode.png" alt=""><p>个人信息</p></router-link></li>
          <!--<li><router-link to="/Memberindex/Memberbasic"><img src="images/guanli.png" alt=""><p>房源管理</p></router-link></li>-->
          <li><router-link to="/Memberindex/Memberhouserecord"><img src="../assets/images/jilu.png" alt=""><p>看房纪录</p></router-link></li>
          <li><router-link to="/Memberindex/Memberpinglun"><img src="../assets/images/pinglun.png" alt=""><p>我的评论</p></router-link></li>
          <li><router-link to="/Memberindex/Memberlookhouse"><img src="../assets/images/baoming.png" alt=""><p>我的报名</p></router-link></li>
          <li><router-link to="/Memberindex/Memberfeedback"><img src="../assets/images/fankui.png" alt=""><p>用户反馈</p></router-link></li>
          <li><router-link to="/Counter"><img src="../assets/images/fangdai.png" alt=""><p>房贷计算器</p></router-link></li>
        </ul>
      </div>
    </div>
</template>

<script>
export default {
  name: 'membermenu'
}
</script>

<style scoped>

</style>
