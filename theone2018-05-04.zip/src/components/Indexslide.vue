
<template>
    <div id="indexslide">
      <div class="content_rg">
        <h2 class="item_title mar_btom">天气<img src="../assets/images/more.png" /></h2>
        <div  class="con_weater">
          <iframe name="weather_inc" src="http://i.tianqi.com/index.php?c=code&id=55"  width="255" height="294" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>

        </div>
        <h2 class="item_title mar_top mar_btom">免费看房<img src="../assets/images/more.png" /></h2>
        <div class="publicar">
          <ul>
            <li>
              <a href="#">免费专车看房</a>
              <p>楼盘单价 2000-12000元／㎡</p>
            </li>
            <li>
              <a href="#">免费专车看房</a>
              <p>楼盘单价 2000-12000元／㎡</p>
            </li>
            <li>
              <a href="#">免费专车看房</a>
              <p>楼盘单价 2000-12000元／㎡</p>
            </li>
            <li>
              <a href="#">免费专车看房</a>
              <p>楼盘单价 2000-12000元／㎡</p>
            </li>
          </ul>
        </div>
      </div>
    </div>
</template>

<script>
export default {
  name: 'indexslide'
}
</script>

<style scoped>

</style>
