<template>
  <div id="app">
    <Topview></Topview>
    <Menuitemview></Menuitemview>
    <router-view></router-view>
    <Footerview></Footerview>
  </div>
</template>

<script>
import Topview from './components/Top'
import Footerview from './components/Footer'
import Menuitemview from './components/Menuitem'
export default {
  name: 'App',
  components: {
    Topview,
    Footerview,
    Menuitemview
  }
}
</script>

<style>

</style>
