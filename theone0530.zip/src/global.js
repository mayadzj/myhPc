window.myHost = '/api/'
// window.myHost = 'http://192.168.0.107:8080/'
// window.myHost = 'http://www.manyihefc.com:8080/'
