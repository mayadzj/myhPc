<template>
    <div id="memberpinglun">
      <div class="comment">
        <div class="comment-tit">
          <p>我的评论</p>
        </div>
        <div class="comment-wap">
          <div class="comment-con-tit clear">
            <div class="tit-lou">
              楼盘(1)
            </div>
            <div class="tit-jingji">
              经纪人(0)
            </div>
          </div>
          <div class="con-one clear">
            <div class="con-one-l">
              2016-05-02 20:43:23
            </div>
            <div class="con-one-m">
              <div class="m-tit">这房子旁边开赌场不见得是好事啊，我国自古以来官方没开过赌场吧</div>
              <div class="m-pic clear">
                <div>+</div>
                <div>+</div>
                <div>+</div>
                <div>+</div>
              </div>
              <div class="con-one-r">
                <p>查看</p>
                <p>删除评论</p>
              </div>
            </div>
          </div>
          <div class="con-two clear">
            <div class="con-one-l">
              2016-05-02 20:43:23
            </div>
            <div class="con-one-m">
              <div class="m-name">worlord001:</div>
              <div class="m-nav">
                美国拉斯维加斯有一点问题吗？ 赌场设得偏远点还是可以的。
              </div>
              <div class="con-one-r">
                <p>回复</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
export default {
  name: 'memberpinglun'
}
</script>

<style scoped>

</style>
