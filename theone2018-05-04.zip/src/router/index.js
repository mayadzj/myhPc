import Vue from 'vue'
import Router from 'vue-router'
import Index from '@/components/Index'
import Counter from '../components/Counter'
import Housesay from '../components/Housesay'
import Housesays from  '../components/Housesays'
import Login from '../components/Login'
import Newslist from '../components/Newslist'
import Newsview from '../components/Newsview'
import Indexart from '../components/Indexart'
import Newhouseshow from '../components/Newhouseshow'
import Searchlist from '../components/Searchlist'
import Houseban from '../components/Houseban'
import Translate from  '../components/Translate'
import Translatesay from  '../components/Translatesay'
import Footer from '../components/Footer'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Index',
      component: Index
    },
    {
      path: '/Counter',
      name: 'Counter',
      component: Counter
    },
    {
      path: '/Housesay',
      name: 'Housesay',
      component: Housesay
    },
    {
      path: '/Housesay/:id',
      name: 'Housesay',
      component: Housesay
    },
    {
      path: '/Housesays/:id',
      name: 'Housesays',
      component: Housesays
    },
    {
      path: '/Login',
      name: 'Login',
      component: Login
    },
    {
      path: '/Login/:cate',
      name: 'Login',
      component: Login
    },
    {
      path: '/Newslist',
      name: 'Newslist',
      component: Newslist
    },
    {
      path: '/Newsview/:id',
      name: 'Newsview',
      component: Newsview
    },
    {
      path: '/Indexart',
      name: 'Indexart',
      component: Indexart
    },
    {
      path: '/Newhouseshow',
      name: 'Newhouseshow',
      component: Newhouseshow
    },
    {
      path: '/Newhouseshow/:id',
      name: 'Newhouseshow',
      component: Newhouseshow
    },
    {
      path: '/Searchlist',
      name: 'Searchlist',
      component: Searchlist
    },
    {
      path: '/Searchlist/:d',
      name: 'Searchlist2',
      component: Searchlist
    },
    {
      path: '/Houseban/:id',
      name: 'Houseban',
      component: Houseban
    },
    {
      path: '/Translate',
      name: 'Translate',
      component: Translate
    },
    {
      path: '/Translatesay/:id',
      name: 'Translatesay',
      component: Translatesay
    },
    {
      path: '/Footer',
      name: 'Footer',
      component: Footer
    }
  ],
  scrollBehavior: () => ({ y: 0 })
})
